import java.io.*;

public class DeserialiserSegments {
    public static void main(String[] args) throws ClassNotFoundException , IOException{
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("Segments.ser")); 
            Segment[] segments = (Segment[]) in.readObject();
            System.out.println("Segments désérialisés :");
            for (Segment segment : segments) {
                segment.afficher();
            }in.close();
    }
}

