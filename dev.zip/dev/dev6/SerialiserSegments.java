import java.io.*;

public class SerialiserSegments {
    public static void main(String[] args)throws IOException {
        Segment[] segments = new Segment[] {
            new Segment(1.0, 2.0, 3.0, 4.0),
            new Segment(5.0, 6.0, 7.0, 8.0),
            new Segment(9.0, 10.0, 11.0, 12.0)
        };
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Segments.ser")) ;
            out.writeObject(segments);
            System.out.println("Segments sérialisés avec succès !");
            out.close();
    
}
}
