import java.io.Serializable;

public class Segment implements Serializable {
    private static final long serialVersionUID = 1L; 

    private double abscisseDebut;
    private double ordonneeDebut;
    private double abscisseFin;
    private double ordonneeFin;

    public Segment(double abscisseDebut, double ordonneeDebut, double abscisseFin, double ordonneeFin) {
        this.abscisseDebut = abscisseDebut;
        this.ordonneeDebut = ordonneeDebut;
        this.abscisseFin = abscisseFin;
        this.ordonneeFin = ordonneeFin;
    }

    public double getAbscisseDebut() {
        return abscisseDebut;
    }

    public double getOrdonneeDebut() {
        return ordonneeDebut;
    }

    public double getAbscisseFin() {
        return abscisseFin;
    }

    public double getOrdonneeFin() {
        return ordonneeFin;
    }

    public void afficher() {
        System.out.println("Segment: (" + abscisseDebut + ", " + ordonneeDebut + ") à (" 
                           + abscisseFin + ", " + ordonneeFin + ")");
    }
}
