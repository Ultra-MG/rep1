import java.io.*;

public class lirefile2 {
    public static void main(String[] args)throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(args[0])) ;
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line); // Print each line
            
        
        }reader.close();
    }
}
 