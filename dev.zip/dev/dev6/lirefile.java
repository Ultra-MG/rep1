import java.io.*;
public class lirefile{
    public static void main(String[] argv) throws IOException  {
DataInputStream lecteur = new DataInputStream(new BufferedInputStream
                                            (new FileInputStream(argv[0])));
    String greeting = lecteur.readUTF();
    int number = lecteur.readInt();
    long bigNumber = lecteur.readLong();
    float decimal = lecteur.readFloat();
    double doubleValue = lecteur.readDouble();
    char character = lecteur.readChar();
    boolean boolValue = lecteur.readBoolean();
    String farewell = lecteur.readUTF();
    System.out.println("Data read from file:");
    System.out.println("Greeting: " + greeting);
    System.out.println("Integer: " + number);
    System.out.println("Long: " + bigNumber);
    System.out.println("Float: " + decimal);
    System.out.println("Double: " + doubleValue);
    System.out.println("Char: " + character);
    System.out.println("Boolean: " + boolValue);
    System.out.println("Farewell: " + farewell);
    lecteur.close();}
}
 