import java.util.ArrayList;
import java.util.Random;

public class testfigure {
    public static void main(String args[]) {
        figure c1 = new carre(1, 2, 2);
        figure c2 = new cercle(1, 3, 4);
        double b1 = c1.surface();
        double b2 = c2.surface();
        System.out.println("cercle surface=" + b2 +
                "\n" + "carre surface=" + b1);
        c1.affiche();
        c2.affiche();
        ArrayList<figure> figures = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            int n = 10000;
            Random r = new Random();
            int d = r.nextInt(n);
            if ((d % 2) == 0) {
                figures.add(new cercle(r.nextInt(n), r.nextInt(n), r.nextInt(n)));
            } else {
                figures.add(new carre(r.nextInt(n), r.nextInt(n), r.nextInt(n)));
            }
        }
        for (int i = 0; i < 10; i++) {
            (figures.get(i)).affiche();
            System.out.println((figures.get(i)).surface());
        }
    }
}