public class voiture {
    private String marque;
    private String modele;
    private int annee;

    public voiture(String marque, String modele, int annee) {
        this.marque = marque;
        this.modele = modele;
        this.annee = annee;
    }
    public String toString() {
        return "{" +
                "marque='" + marque + '\'' +
                ", modele='" + modele + '\'' +
                ", annee=" + annee +
                '}';
    }
    public static void main(String[] args){
        voiture v=new voiture("toyota","corolla",2020);
	System.out.println("une voiture"+v);
}
}