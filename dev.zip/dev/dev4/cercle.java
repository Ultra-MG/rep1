public class cercle extends figure{
    private int rayon;
    private double x;
    private double y;
    cercle(int rayon , double x,double y){
        super(x,y);
        this.rayon=rayon;
    }
    public double surface(){
        double b=(Math.PI)*(rayon^2);
        return b;
    }
    public void affiche(){
        System.out.println("je suis un cercle");
    }
}