abstract class figure{
    private double x;
    private double y;
    figure(double x1 , double y1){
        this.x=x1;
        this.y=y1;
    }
    figure(){
        this.x=50;
        this.y=50;
    }
    public abstract double surface();
    public abstract void affiche();
}