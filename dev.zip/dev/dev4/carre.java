public class carre extends figure{
            private int cote;
            private double x;
            private double y;
            carre(int cote , double x,double y){
                this.x=x;
                this.y=y;
                this.cote=cote;
            }
            public double surface(){
                double b=cote^2;
                return b;
            }
            public void affiche(){
                System.out.println("je suis un carre");
            }
}