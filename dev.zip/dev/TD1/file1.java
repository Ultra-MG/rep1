package TD1;

public class file1 {
    public static void main(String args[]) {}
};
class cercle{

    private int rayon;
    private int[] x=new int[2];
 public cercle(int r,int x1,int y1){
        rayon=r;
        x[0]=x1;
        x[1]=y1;
     }
  public cercle(int r){
    this(r,0,0);
  }
public int getrayon(){
    return rayon;
}
public int getx(){
    return x[0];
}
public int gety(){
    return x[1];
}
public void setrayon(int r){
    rayon=r;
}
public void setx(int x1){
    x[0]=x1;
}
public void sety(int y1){
    x[1]=y1;
}
public void information(){
    System.out.println("rayon=" + rayon);
    System.out.println("x=" + x[0]);
    System.out.println("y=" + x[1]);
}
public static void main(String args[]) {
    cercle c=new cercle(1,2,3);
    c.information();
}
};
class testcircle {
    public static void main(String[] args) {
        // Création de divers objets Cercle
        cercle c1 = new cercle(5, 10, 15); //utilisation du constructeur 
        cercle c2 = new cercle(7); // utilisation du constructeur surchargé
        // cercle c3; //cercle non instancie
        // cercle c4=new cercle(); //constructeur par defaut 
        // affichage des info cercle 1
        System.out.println("Informations du cercle1 :");
        c1.information();
        
        //  info cercle 2
        System.out.println("\nInformations du cercle2 :");
        c2.information();
        // attribut d'un object non instancie
        // System.out.println("Informations du cercle3 :");
        // c3.information();

        // Test des getters
        System.out.println("\nTest des getters :");
        System.out.println("c1 rayon = " + c1.getrayon());
        System.out.println("c1 x = " + c1.getx());
        System.out.println("c1 y = " + c1.gety());

        // Test des setters
        c2.setrayon(12);
        c2.setx(20);
        c2.sety(25);

        // Affichage des nouvelles informations du cercle2
        System.out.println("\nInformations mises à jour du cercle2 :");
        c2.information();
    }
}
