class Print{
        public void Print1(){
                System.out.println("this is the old class");
        } 
    }
abstract class adapter_abs{
        public abstract void Print2();
}
class adapter_conc extends adapter_abs{
        private Print prt;
        public adapter_conc(){
            this.prt=new Print();
        }
        public void Print2(){
                System.out.println("this is the new adapter");
                prt.Print1();
        }
}
public class Adapter{
    public static void main(String args[]){
            adapter_abs adapt1=new adapter_conc();
            adapt1.Print2();
    }

}