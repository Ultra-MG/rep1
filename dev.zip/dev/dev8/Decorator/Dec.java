abstract class Beverage{
        abstract public double cost();
        abstract public void name();
}
class Mocha extends Beverage{
    public double cost(){
        return 20;
    }
    public void name(){
        System.out.print("mocha");
    }
}
class HouseBlend extends Beverage{
    public double cost(){
        return 25;
    }
    public void name(){
        System.out.print("House Blend");
    }
}
class Decaf extends Beverage{
    public double cost(){
        return 15;
    }
    public void name(){
        System.out.print("Decaf");
    }
}
class DarkRoast extends Beverage{
    public double cost(){
        return 16.8;
    }
    public void name(){
        System.out.print("Dark Roast");
    }
}
class Coffe extends Beverage{
    public double cost(){
        return 20;
    }
    public void name(){
        System.out.print("Coffe");
    }
}
abstract class Decorator extends Beverage{
    Beverage bvg1;
    public Decorator(Beverage bvg1){
        this.bvg1=bvg1;
    }
    abstract public void name();
    abstract public double cost();
}
class Milk extends Decorator{
    public Milk(Beverage bvg1){
        super(bvg1);
    }
    public void name(){
        bvg1.name();
        System.out.print(" + Milk ");
    }
    public double cost(){
        return 3+bvg1.cost();
    }
}
class Extra_coffe extends Decorator{
    public Extra_coffe(Beverage bvg1){
        super(bvg1);
    }
    public void name(){
        bvg1.name();
        System.out.print(" + Extra coffe ");
    }
    public double cost(){
        return 4+bvg1.cost();
    }
}
class Soy extends Decorator{
    public Soy(Beverage bvg1){
        super(bvg1);
    }
    public void name(){
        bvg1.name();
        System.out.print(" + Soy ");
    }
    public double cost(){
        return 5+bvg1.cost();
    }
}
class Whip extends Decorator{
    public Whip(Beverage bvg1){
        super(bvg1);
    }
    public void name(){
        bvg1.name();
        System.out.print(" + Whip ");
    }
    public double cost(){
        return 3.5+bvg1.cost();
    }
}
class Almond_Milk extends Decorator{
    public Almond_Milk(Beverage bvg1){
        super(bvg1);
    }
    public void name(){
        bvg1.name();
        System.out.print(" + Almond Milk ");
    }
    public double cost(){
        return 7+bvg1.cost();
    }
}
public class Dec{
    public static void main(String agr[]){
        Beverage mc1=new Mocha();
        Beverage mc2=new Milk(mc1);
        Beverage mc3=new Whip(mc2);
        double a=mc3.cost();
        mc3.name();
        System.out.println("==>cost="+a);
        Beverage m1=new Coffe();
        Beverage m2=new Whip(m1);
        Beverage m3=new Almond_Milk(m2);
        Beverage m4=new Soy(m3);
        m4.name();
        System.out.println("==>cost="+m4.cost());
    }
}