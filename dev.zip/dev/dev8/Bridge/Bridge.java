abstract class Shape_impl{
    abstract public void drawc();
    abstract public void drawr();
    abstract public void getsizesc(float x,float y,float r);
    abstract public void getsizesr(float x,float y,float L,float l);
}
class Impl1 extends Shape_impl{
    public void getsizesc(float x,float y,float r){
        System.out.println("in cm:"+"\n"+"x="+x+"\n"+"y="+y+"\n"+"r="+r);
    }
    public void getsizesr(float x,float y,float L,float l){
        System.out.println("in cm:"+"\n"+"x="+x+"\n"+"y="+y+"\n"+"l="+l+"\n"+"L="+L);
    }
    public void drawc(){
        System.out.println("drawing circle using method 1");
    }
    public void drawr(){
        System.out.println("drawing retangle using method 1");
    }
}
class Impl2 extends Shape_impl{
    public void getsizesc(float x,float y,float r){
        double x1=x*0.394;
        double y1=y*0.394;
        double r1=r*0.394;
        System.out.println("in inches:"+"\n"+"x="+x1+"\n"+"y="+y1+"\n"+"r="+r1);
    }
    public void getsizesr(float x,float y,float L,float l){
        double x1=x*0.394;
        double y1=y*0.394;
        double l1=l*0.394;
        double L1=L*0.394;
        System.out.println("in inches:"+"\n"+"x="+x1+"\n"+"y="+y1+"\n"+"l="+l1+"\n"+"L="+L1);
    }
    public void drawc(){
        System.out.println("drawing circle using method 2");
    }
    public void drawr(){
        System.out.println("drawing retangle using method 2");
    }
}
abstract class Shape {
    abstract public void draw();
    abstract public void getsizes();
}
class Circle extends Shape{
    private float x;
    private float y;
    private float r;
    private Shape_impl implem;
    public Circle(float x,float y,float r,Shape_impl impl3){
        this.x=x;
        this.y=y;
        this.r=r;
        this.implem=impl3;
    }
    public void draw(){
        implem.drawc();
    }
    public void getsizes(){
        implem.getsizesc(x,y,r);
    }
}
class Rectangle extends Shape{
    private float x;
    private float y;
    private float l;
    private float L;
    private Shape_impl implem;
    public Rectangle(float x,float y,float l,float L,Shape_impl impl3){
        this.x=x;
        this.y=y;
        this.l=l;
        this.L=L;
        this.implem=impl3;
    }
    public void draw(){
         implem.drawr();
    }
    public void getsizes(){
        implem.getsizesr(x,y,L,l);
    }
}
public class Bridge{
    public static void main(String args[]){
        Shape rec1=new Rectangle(1,2,3,4,new Impl1());
        Shape cer1=new Circle(1,1,5,new Impl2());
        rec1.draw();
        rec1.getsizes();
        cer1.draw();
        cer1.getsizes();
    }
}