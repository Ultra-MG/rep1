public class ExprString { 
    public static void main(String args[]) {  
            System.out.println('a'); 
            System.out.println('\n'); 
            System.out.println('\u1234');
            System.out.println('\\');
            System.out.println('\"');
            System.out.println("aujourd'hui");
            System.out.println("dites \"Ahh!\".");
            System.out.println("\tun\ttexte\ttres\tespace\t!");
            System.out.println("deux"+"deux");
            System.out.println('o'+'k');
            System.out.println('o'+"k");           
    } }