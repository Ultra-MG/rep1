public class Scope { 
    public static void main(String args[]) {  
        for (int i=0; i < 5; i++) { 
            System.out.print(i + ", "); 
        } 
        System.out.print("\n"); 
    } 
} 
class Variables { 
    public static void main(String args[]) { 
        double a = 3; 
        double b = 4; 
        double c; 
        c = Math.sqrt(a * a + b * b); 
        System.out.println("c = " + c); 
    } 
} 
class Promote { 
    public static void main(String args[]) { 
        byte b = 42; 
        char c = 'a'; 
        short s = 1024; 
        int i = 50000; 
        float f = 5.67f; 
        double d = .1234; 
double resultat = (f * b) + (i / c) - (d * s); 
System.out.print((f * b) + " + " + (i / c) + " - " + (d * s)); 
System.out.println(" = " + resultat); 
byte b2 = 10; 
byte b3 = (byte)(b2 * b); 
System.out.println("b3 = " + b3); 
} 
}