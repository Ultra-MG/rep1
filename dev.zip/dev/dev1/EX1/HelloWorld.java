public class HelloWorld {   /**this is a class */
    public static void main(String argv[]) { 
        System.out.println("BONJOUR\nCECI EST MON\nPREMIER PROGRAMME JAVA\n"); /**this line displays a string */
    } 
} 