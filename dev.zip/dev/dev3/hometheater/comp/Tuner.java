package comp;
public class Tuner{
    private String name;
    public Tuner(String name1,Amplifier amp){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void setFrequency(double fre){
        System.out.println(name + " frequency us set to" + fre);
    }
}
