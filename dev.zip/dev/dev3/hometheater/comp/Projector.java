package comp;
public class Projector{
    private String name;
    public Projector(String name1,DvdPlayer amp){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void wideScreenMode(){
        System.out.println(name + " is in wide screen mode");
    }
}
