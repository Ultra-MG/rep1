package comp;
public class Screen{
    private String name;
    public Screen(String name1){
        this.name=name1;
    }
    public void up(){;
        System.out.println(name + " is up");
    }
    public void down(){
        System.out.println(name + " is down");
    }
}
