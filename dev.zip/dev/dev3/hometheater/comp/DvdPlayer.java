package comp;
public class DvdPlayer{
    private String name;
    public DvdPlayer(String name1,Amplifier amp){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void play(String name2){
        System.out.println(name + " playing" + name2);
    }
    public void eject(){
        System.out.println(name + " is ejectng cd");
        }
    public void stop(){
        System.out.println(name + " is stopping");
        }
    }