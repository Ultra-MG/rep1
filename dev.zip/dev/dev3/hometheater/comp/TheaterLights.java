package comp;
public class TheaterLights{
    private String name;
    public TheaterLights(String name1){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void dim(int nbr){
        System.out.println(name + " dimming level set to " + nbr  + "%");
    }
}
