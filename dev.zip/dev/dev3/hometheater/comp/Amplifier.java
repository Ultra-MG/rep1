package comp;
public class Amplifier{
    private String name;
    public Amplifier(String name1){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void setDvd(DvdPlayer name12){
    System.out.println(name + " setting dvd to" + name12);
    }
    public void setCd(CdPlayer name12){
        System.out.println(name + " setting CD player to" + name12);
        }
    public void setTuner(Tuner name12){
        System.out.println(name + " setting CD player to" + name12);
        }    
    public void setSurroundSound(){
        System.out.println("surround sound in on");
        }
    public void setStereoSound(){
        System.out.println(name + " is setting Stereo sound");
        }
    public void setVolume(int nbr){
        System.out.println(name +  " setting volume to " + nbr);
    }
}

