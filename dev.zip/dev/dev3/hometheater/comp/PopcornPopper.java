package comp;
public class PopcornPopper{
    private String name;
    public PopcornPopper(String name1){
        this.name=name1;
    }
    public void on(){;
        System.out.println(name + " is on");
    }
    public void off(){
        System.out.println(name + " is off");
    }
    public void pop(){
        System.out.println(name +  " is popping popcorn");
    }
}
