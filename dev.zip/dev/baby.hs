doubleme x= x + x
doubleus x y = doubleme x + doubleme y

double100 x=if x<100 then x+x else x

sayme :: (Num a) => a -> String 
sayme x ="ssas"



bmicalc :: (RealFloat a) => a -> a -> String
bmicalc x y 
      | x/y^2 <=18.5 ="fuck off you skinny bitch"
      | x/y^2 <=25 ="you are normal fucking nigger "
      | x/y^2 <=30 =" get your bitch ass out of here and lose some fucking weight you fast ass"
      | otherwise =" suicide dickhead , fucking bitch ass fat ass whale fuck you nigger"

bmivalue :: (RealFloat a) => a -> a -> a
bmivalue x y = x/y^2

initial :: String -> String 
initial x = [f] ++ ". " ++ [l] ++ "."
   where (a:b)=x
         (f:_)=a
         (l:_)=b
         


